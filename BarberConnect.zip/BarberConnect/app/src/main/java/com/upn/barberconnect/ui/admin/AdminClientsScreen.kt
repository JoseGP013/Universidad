package com.upn.barberconnect.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.money

@Composable
fun AdminClientsScreen(vm: AdminViewModel) {
    val clients by vm.clients.collectAsStateWithLifecycle()
    val query by vm.clientQuery.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        ScreenTitle("Directorio de Clientes")
        Box(Modifier.padding(horizontal = 20.dp)) {
            AppTextField(query, { vm.clientQuery.value = it }, "Buscar por nombre o teléfono...", icon = Icons.Default.Search)
        }
        LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (clients.isEmpty()) item { EmptyState("No se encontraron clientes.") }
            items(clients, key = { it.id }) { c ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold)
                            Text("📱 ${c.phone} • ${c.email}", color = MutedText, fontSize = 12.sp)
                        }
                        if (c.visits >= 3) {
                            Surface(color = Gold.copy(alpha = 0.15f), shape = RoundedCornerShape(50)) {
                                Text("Frecuente", color = Gold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Text("Visitas: ", color = MutedText, fontSize = 12.sp)
                        Text("${c.visits}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.width(16.dp))
                        Text("Inversión acumulada: ", color = MutedText, fontSize = 12.sp)
                        Text(money(c.total), color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
