package com.upn.barberconnect.ui.client

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.upn.barberconnect.data.BarberRepository
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.data.local.Barber
import com.upn.barberconnect.data.local.ServiceItem
import com.upn.barberconnect.util.stateInVm
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

data class BookingState(
    val service: ServiceItem? = null,
    val barberId: Long? = null,
    val date: LocalDate = LocalDate.now(),
    val time: String? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val confirmedCode: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class ClientViewModel(
    private val repo: BarberRepository,
    val user: SessionUser
) : ViewModel() {

    // ----- HU02: catálogo con búsqueda -----
    val query = MutableStateFlow("")
    val services = combine(repo.activeServices(), query) { list, q ->
        if (q.isBlank()) list else list.filter { it.name.contains(q, true) || it.description.contains(q, true) }
    }.stateInVm(this, emptyList())

    val barbers = repo.barbers().stateInVm(this, emptyList<Barber>())

    // ----- HU04 / HU05 -----
    val appointments = repo.clientAppointments(user.id).stateInVm(this, emptyList())
    val notifications = repo.notifications(user.id).stateInVm(this, emptyList())
    val unread = repo.unreadCount(user.id).stateInVm(this, 0)

    // ----- HU03: reserva en tiempo real -----
    private val _booking = MutableStateFlow(BookingState())
    val booking: StateFlow<BookingState> = _booking.asStateFlow()

    /** Horarios ocupados del barbero/fecha elegidos; se actualiza en vivo desde Room. */
    val takenTimes: StateFlow<List<String>> = _booking
        .map { it.barberId to it.date }
        .distinctUntilChanged()
        .flatMapLatest { (barber, date) ->
            if (barber == null) flowOf(emptyList()) else repo.takenTimes(barber, date.toString())
        }.stateInVm(this, emptyList())

    fun startBooking(serviceId: Long) {
        viewModelScope.launch {
            val s = repo.service(serviceId)
            _booking.value = BookingState(service = s, barberId = barbers.value.firstOrNull()?.id)
        }
    }

    fun selectBarber(id: Long) = _booking.update { it.copy(barberId = id, time = null, error = null) }
    fun selectDate(d: LocalDate) = _booking.update { it.copy(date = d, time = null, error = null) }
    fun selectTime(t: String) = _booking.update { it.copy(time = t, error = null) }
    fun clearBookingResult() = _booking.update { it.copy(confirmedCode = null) }

    fun confirmBooking() {
        val b = _booking.value
        val service = b.service ?: return
        val barber = b.barberId ?: return
        val time = b.time
        if (time == null) {
            _booking.update { it.copy(error = "Por favor selecciona un horario disponible.") }
            return
        }
        viewModelScope.launch {
            _booking.update { it.copy(loading = true, error = null) }
            repo.book(user.id, service.id, barber, b.date.toString(), time).fold(
                onSuccess = { code -> _booking.update { it.copy(loading = false, confirmedCode = code) } },
                onFailure = { e -> _booking.update { it.copy(loading = false, time = null, error = e.message) } }
            )
        }
    }

    fun cancelAppointment(id: Long) = viewModelScope.launch { repo.cancelAppointment(id) }
    fun markNotificationsRead() = viewModelScope.launch { repo.markAllRead(user.id) }
}
