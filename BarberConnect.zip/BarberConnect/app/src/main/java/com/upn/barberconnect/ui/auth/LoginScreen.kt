package com.upn.barberconnect.ui.auth

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.upn.barberconnect.AppViewModelFactory
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.data.local.Role
import com.upn.barberconnect.rememberContainer
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*

@Composable
fun LoginScreen(onLoggedIn: (SessionUser) -> Unit, onRegister: () -> Unit) {
    val vm: AuthViewModel = viewModel(factory = AppViewModelFactory(rememberContainer()))
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    // Credenciales de demostración (quitar antes de la entrega final)
    var email by remember { mutableStateOf("cliente@barber.com") }
    var pass by remember { mutableStateOf("123456") }

    LaunchedEffect(state.user) {
        state.user?.let { onLoggedIn(it); vm.consumeUser() }
    }

    Column(
        Modifier.fillMaxSize().background(DarkBg).verticalScroll(rememberScrollState())
            .padding(horizontal = 32.dp).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(32.dp))
        Box(Modifier.size(96.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) {
            Text("✂", fontSize = 44.sp, color = androidx.compose.ui.graphics.Color.Black)
        }
        Spacer(Modifier.height(16.dp))
        Text("BARBER\nCONNECT", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, letterSpacing = 3.sp, lineHeight = 34.sp)
        Text("Gestión y Reserva de Citas", color = MutedText, fontSize = 13.sp)
        Spacer(Modifier.height(32.dp))

        AppTextField(email, { email = it; vm.clearError() }, "Correo electrónico", icon = Icons.Default.Email, keyboardType = KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        AppTextField(pass, { pass = it; vm.clearError() }, "Contraseña", icon = Icons.Default.Lock, isPassword = true)

        Text(
            "¿Olvidaste tu contraseña?", color = Gold, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.End).padding(top = 8.dp)
                .clickable { Toast.makeText(ctx, "Recuperación de contraseña: próximamente (Firebase Auth)", Toast.LENGTH_SHORT).show() }
        )

        state.error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = Danger, fontSize = 12.sp, textAlign = TextAlign.Center)
        }

        Spacer(Modifier.height(20.dp))
        GoldButton("Ingresar como Cliente", { vm.login(email, pass, Role.CLIENT) }, loading = state.loading)
        Spacer(Modifier.height(10.dp))
        OutlinedGoldButton("Ingresar como Admin", { vm.login(email, pass, Role.ADMIN) })

        Spacer(Modifier.height(16.dp))
        Row {
            Text("¿No tienes cuenta? ", color = MutedText, fontSize = 12.sp)
            Text("Regístrate", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onRegister() })
        }
        Spacer(Modifier.height(8.dp))
        Text("Demo → cliente@barber.com / 123456 · admin@barber.com / admin123",
            color = MutedText, fontSize = 10.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
    }
}
