package com.upn.barberconnect.ui.admin

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.ui.components.AppCard
import com.upn.barberconnect.ui.components.GoldButton
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.money
import java.time.LocalDate

@Composable
fun DashboardScreen(vm: AdminViewModel, onLogout: () -> Unit) {
    val income by vm.incomeToday.collectAsStateWithLifecycle()
    val active by vm.activeCount.collectAsStateWithLifecycle()
    val weekly by vm.weekly.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    Column(Modifier.fillMaxSize().background(DarkBg).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Panel de Administración", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Control Centralizado de Negocio", color = MutedText, fontSize = 12.sp)
            }
            IconButton(onClick = onLogout) { Icon(Icons.AutoMirrored.Filled.ExitToApp, "Cerrar sesión", tint = MutedText) }
        }
        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            KpiCard("Ingresos del Día", money(income), Modifier.weight(1f))
            KpiCard("Citas Activas", "$active", Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))

        AppCard {
            Text("Ingresos de los últimos 7 días", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            val max = (weekly.maxOfOrNull { it.total } ?: 0.0).coerceAtLeast(1.0)
            Row(
                Modifier.fillMaxWidth().height(130.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                weekly.forEach { bar ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        if (bar.total > 0) Text("${bar.total.toInt()}", fontSize = 9.sp, color = MutedText)
                        Box(
                            Modifier.width(26.dp).height((90 * (bar.total / max)).coerceAtLeast(4.0).dp)
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(if (bar.total > 0) Gold else BorderGray)
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                weekly.forEach { Text(it.label, fontSize = 10.sp, color = MutedText) }
            }
        }
        Spacer(Modifier.height(16.dp))

        // PENDIENTE: exportación real a PDF/imagen. Por ahora se comparte un resumen en texto.
        GoldButton("Compartir reporte", {
            val text = buildString {
                appendLine("Reporte Barber Connect – ${LocalDate.now()}")
                appendLine("Ingresos del día: ${money(income)}")
                appendLine("Citas activas: $active")
                appendLine("Últimos 7 días:")
                weekly.forEach { appendLine("  ${it.label}: ${money(it.total)}") }
            }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            ctx.startActivity(Intent.createChooser(send, "Compartir reporte"))
        })
    }
}

@Composable
private fun KpiCard(title: String, value: String, modifier: Modifier) {
    AppCard(modifier) {
        Text(title, color = MutedText, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp)
    }
}
