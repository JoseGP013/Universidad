package com.upn.barberconnect.ui.client

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.data.local.AppointmentDetail
import com.upn.barberconnect.data.local.Status
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.money

@Composable
fun MyAppointmentsScreen(vm: ClientViewModel) {
    val all by vm.appointments.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    var toCancel by remember { mutableStateOf<AppointmentDetail?>(null) }

    val upcoming = all.filter { it.status == Status.CONFIRMADA || it.status == Status.EN_PROCESO }
    val history = all.filter { it.status == Status.COMPLETADA || it.status == Status.CANCELADA }
    val list = if (tab == 0) upcoming else history

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        ScreenTitle("Mis Reservas")
        TabRow(selectedTabIndex = tab, containerColor = DarkBg, contentColor = Gold) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Próximas (${upcoming.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Historial (${history.size})") })
        }
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (list.isEmpty()) item { EmptyState(if (tab == 0) "No tienes citas programadas." else "Aún no tienes historial.") }
            items(list, key = { it.id }) { a ->
                AppCard {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            StatusChip(a.status)
                            Spacer(Modifier.height(6.dp))
                            Text(a.serviceName, fontWeight = FontWeight.Bold)
                            Text("#${a.code}", color = MutedText, fontSize = 11.sp)
                        }
                        Text(money(a.price), color = Gold, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("📅 ${a.date}   🕐 ${a.time} hrs", color = MutedText, fontSize = 12.sp)
                    Text("✂ Barbero: ${a.barberName}", color = MutedText, fontSize = 12.sp)
                    if (a.status == Status.CONFIRMADA) {
                        TextButton(onClick = { toCancel = a }) { Text("Cancelar cita", color = Danger) }
                    }
                }
            }
        }
    }

    toCancel?.let { a ->
        AlertDialog(
            onDismissRequest = { toCancel = null },
            containerColor = CardBg,
            title = { Text("Cancelar cita") },
            text = { Text("¿Estás seguro de cancelar tu cita #${a.code}? El horario quedará libre para otros clientes.") },
            confirmButton = {
                TextButton(onClick = { vm.cancelAppointment(a.id); toCancel = null }) { Text("Sí, cancelar", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { toCancel = null }) { Text("Volver", color = MutedText) } }
        )
    }
}
