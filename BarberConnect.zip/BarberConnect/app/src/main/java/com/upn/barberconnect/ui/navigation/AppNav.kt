package com.upn.barberconnect.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.data.local.Role
import com.upn.barberconnect.rememberContainer
import com.upn.barberconnect.ui.admin.AdminRoot
import com.upn.barberconnect.ui.auth.LoginScreen
import com.upn.barberconnect.ui.auth.RegisterScreen
import com.upn.barberconnect.ui.client.ClientRoot

private const val LOGIN = "login"
private const val REGISTER = "register"
private const val CLIENT = "client"
private const val ADMIN = "admin"

@Composable
fun AppNav() {
    val container = rememberContainer()
    val nav = rememberNavController()
    val start = remember {
        container.session.get()?.let { if (it.role == Role.ADMIN) ADMIN else CLIENT } ?: LOGIN
    }

    fun goHome(u: SessionUser) = nav.navigate(if (u.role == Role.ADMIN) ADMIN else CLIENT) {
        popUpTo(nav.graph.id) { inclusive = true }
    }
    fun logout() {
        container.session.clear()
        nav.navigate(LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
    }

    NavHost(nav, startDestination = start) {
        composable(LOGIN) { LoginScreen(onLoggedIn = { goHome(it) }, onRegister = { nav.navigate(REGISTER) }) }
        composable(REGISTER) { RegisterScreen(onRegistered = { goHome(it) }, onBack = { nav.popBackStack() }) }
        composable(CLIENT) {
            val user = container.session.get()
            if (user == null) RedirectToLogin(nav) else ClientRoot(user, onLogout = ::logout)
        }
        composable(ADMIN) {
            if (container.session.get() == null) RedirectToLogin(nav) else AdminRoot(onLogout = ::logout)
        }
    }
}

@Composable
private fun RedirectToLogin(nav: NavHostController) {
    LaunchedEffect(Unit) { nav.navigate(LOGIN) { popUpTo(nav.graph.id) { inclusive = true } } }
}
