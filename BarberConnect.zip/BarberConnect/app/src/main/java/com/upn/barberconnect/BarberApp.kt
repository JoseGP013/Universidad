package com.upn.barberconnect

import android.app.Application
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.upn.barberconnect.data.BarberRepository
import com.upn.barberconnect.data.SessionManager
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.data.local.AppDatabase
import com.upn.barberconnect.ui.admin.AdminViewModel
import com.upn.barberconnect.ui.auth.AuthViewModel
import com.upn.barberconnect.ui.client.ClientViewModel

/** Contenedor de dependencias manual (suficiente para este alcance; migrable a Hilt). */
class AppContainer(context: Context) {
    private val db = AppDatabase.get(context)
    val repository = BarberRepository(db)
    val session = SessionManager(context)
}

class BarberApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

@Composable
fun rememberContainer(): AppContainer =
    (LocalContext.current.applicationContext as BarberApp).container

class AppViewModelFactory(
    private val container: AppContainer,
    private val user: SessionUser? = null
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(AuthViewModel::class.java) ->
            AuthViewModel(container.repository, container.session) as T
        modelClass.isAssignableFrom(ClientViewModel::class.java) ->
            ClientViewModel(container.repository, requireNotNull(user)) as T
        modelClass.isAssignableFrom(AdminViewModel::class.java) ->
            AdminViewModel(container.repository) as T
        else -> throw IllegalArgumentException("ViewModel desconocido: ${modelClass.name}")
    }
}
