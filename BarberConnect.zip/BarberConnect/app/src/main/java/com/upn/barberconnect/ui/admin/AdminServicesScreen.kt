package com.upn.barberconnect.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.data.local.ServiceItem
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.money

@Composable
fun AdminServicesScreen(vm: AdminViewModel) {
    val services by vm.services.collectAsStateWithLifecycle()
    // null = diálogo cerrado; ServiceItem con id=0 = nuevo
    var editing by remember { mutableStateOf<ServiceItem?>(null) }

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        Row(Modifier.fillMaxWidth().padding(end = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("Catálogo de Servicios", modifier = Modifier.weight(1f))
            Button(
                onClick = { editing = ServiceItem(name = "", description = "", durationMin = 30, price = 0.0) },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
            ) { Text("+ Nuevo", fontWeight = FontWeight.Bold) }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(services, key = { it.id }) { s ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold)
                            Text("${money(s.price)} • ${s.durationMin} min", color = MutedText, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Switch(
                                checked = s.active, onCheckedChange = { vm.toggleService(s) },
                                colors = SwitchDefaults.colors(checkedTrackColor = Gold, checkedThumbColor = Color.Black)
                            )
                            Text(if (s.active) "Activo" else "Inactivo", fontSize = 10.sp, color = if (s.active) Success else MutedText)
                        }
                    }
                    TextButton(onClick = { editing = s }) { Text("Editar", color = Gold) }
                }
            }
        }
    }

    editing?.let { s ->
        ServiceDialog(s, onDismiss = { editing = null }) { vm.saveService(it); editing = null }
    }
}

@Composable
private fun ServiceDialog(initial: ServiceItem, onDismiss: () -> Unit, onSave: (ServiceItem) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var desc by remember { mutableStateOf(initial.description) }
    var price by remember { mutableStateOf(if (initial.price > 0) initial.price.toString() else "") }
    var duration by remember { mutableStateOf(initial.durationMin.toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(if (initial.id == 0L) "Nuevo servicio" else "Editar servicio", color = Gold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AppTextField(name, { name = it }, "Nombre")
                AppTextField(desc, { desc = it }, "Descripción")
                AppTextField(price, { price = it }, "Precio (S/)", keyboardType = KeyboardType.Decimal)
                AppTextField(duration, { duration = it }, "Duración (min)", keyboardType = KeyboardType.Number)
                error?.let { Text(it, color = Danger, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = price.replace(',', '.').toDoubleOrNull()
                val d = duration.toIntOrNull()
                if (name.isBlank() || p == null || p <= 0 || d == null || d <= 0) {
                    error = "Completa el nombre; precio y duración deben ser mayores a 0."
                } else {
                    onSave(initial.copy(name = name.trim(), description = desc.trim().ifBlank { "Servicio registrado por administración" }, price = p, durationMin = d))
                }
            }) { Text("Guardar", color = Gold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = MutedText) } }
    )
}
