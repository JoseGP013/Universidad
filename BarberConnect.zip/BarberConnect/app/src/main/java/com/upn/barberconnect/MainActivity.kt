package com.upn.barberconnect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.upn.barberconnect.ui.navigation.AppNav
import com.upn.barberconnect.ui.theme.BarberConnectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BarberConnectTheme { AppNav() }
        }
    }
}
