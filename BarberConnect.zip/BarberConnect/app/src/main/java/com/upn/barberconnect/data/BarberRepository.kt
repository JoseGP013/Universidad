package com.upn.barberconnect.data

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.upn.barberconnect.data.local.*
import com.upn.barberconnect.util.Security
import kotlinx.coroutines.flow.Flow

class BarberRepository(private val db: AppDatabase) {

    // ---------- Autenticación (HU01) ----------
    suspend fun login(email: String, password: String): User? {
        val user = db.userDao().findByEmail(email.trim().lowercase()) ?: return null
        return if (user.passwordHash == Security.hash(password)) user else null
    }

    suspend fun registerClient(name: String, email: String, phone: String, password: String): Result<User> =
        try {
            val user = User(
                name = name.trim(), email = email.trim().lowercase(), phone = phone.trim(),
                passwordHash = Security.hash(password), role = Role.CLIENT
            )
            val id = db.userDao().insert(user)
            Result.success(user.copy(id = id))
        } catch (e: SQLiteConstraintException) {
            Result.failure(IllegalStateException("Ese correo ya está registrado."))
        }

    // ---------- Servicios (HU02 / HU07) ----------
    fun activeServices(): Flow<List<ServiceItem>> = db.serviceDao().observeActive()
    fun allServices(): Flow<List<ServiceItem>> = db.serviceDao().observeAll()
    suspend fun service(id: Long): ServiceItem? = db.serviceDao().getById(id)
    suspend fun saveService(s: ServiceItem) { db.serviceDao().upsert(s) }

    fun barbers(): Flow<List<Barber>> = db.barberDao().observeAll()

    // ---------- Citas (HU03 / HU04 / HU06) ----------
    fun takenTimes(barberId: Long, date: String): Flow<List<String>> =
        db.appointmentDao().observeTakenTimes(barberId, date)

    fun clientAppointments(clientId: Long) = db.appointmentDao().observeByClient(clientId)
    fun allAppointments() = db.appointmentDao().observeAll()

    /** RNF08: la verificación y el insert ocurren en una sola transacción para evitar doble reserva. */
    suspend fun book(clientId: Long, serviceId: Long, barberId: Long, date: String, time: String): Result<String> =
        db.withTransaction {
            val dao = db.appointmentDao()
            if (dao.countConflicts(barberId, date, time) > 0) {
                Result.failure<String>(IllegalStateException("Ese horario ya fue reservado. Elige otro, por favor."))
            } else {
                val code = "BC-" + (1000..9999).random()
                dao.insert(
                    Appointment(
                        code = code, clientId = clientId, serviceId = serviceId, barberId = barberId,
                        date = date, time = time, status = Status.CONFIRMADA
                    )
                )
                db.notificationDao().insert(
                    AppNotification(
                        userId = clientId, title = "Nueva cita confirmada",
                        message = "Tu reserva #$code quedó registrada para el $date a las $time."
                    )
                )
                Result.success(code)
            }
        }

    suspend fun cancelAppointment(id: Long) {
        db.withTransaction {
            val a = db.appointmentDao().getById(id)
            if (a != null) {
                db.appointmentDao().updateStatus(id, Status.CANCELADA)
                db.notificationDao().insert(
                    AppNotification(userId = a.clientId, title = "Cita cancelada", message = "Tu reserva #${a.code} fue cancelada.")
                )
            }
        }
    }

    suspend fun updateStatus(id: Long, status: String) {
        db.withTransaction {
            val a = db.appointmentDao().getById(id)
            if (a != null) {
                db.appointmentDao().updateStatus(id, status)
                db.notificationDao().insert(
                    AppNotification(
                        userId = a.clientId, title = "Estado de tu cita",
                        message = "Tu reserva #${a.code} ahora está: ${Status.label(status)}."
                    )
                )
            }
        }
    }

    // ---------- Notificaciones (HU05) ----------
    fun notifications(userId: Long) = db.notificationDao().observeByUser(userId)
    fun unreadCount(userId: Long) = db.notificationDao().observeUnreadCount(userId)
    suspend fun markAllRead(userId: Long) = db.notificationDao().markAllRead(userId)

    // ---------- Administración (HU08 / HU09) ----------
    fun clientSummaries() = db.userDao().observeClientSummaries()
    fun activeCount() = db.appointmentDao().observeActiveCount()
    fun incomeForDate(date: String) = db.appointmentDao().observeIncomeForDate(date)
    fun incomeBetween(from: String, to: String) = db.appointmentDao().observeIncomeBetween(from, to)
}
