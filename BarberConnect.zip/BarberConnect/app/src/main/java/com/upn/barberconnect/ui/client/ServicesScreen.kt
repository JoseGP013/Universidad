package com.upn.barberconnect.ui.client

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.data.local.ServiceItem
import com.upn.barberconnect.ui.components.AppCard
import com.upn.barberconnect.ui.components.AppTextField
import com.upn.barberconnect.ui.components.EmptyState
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.money

@Composable
fun ServicesScreen(vm: ClientViewModel, onReserve: (Long) -> Unit, onLogout: () -> Unit) {
    val services by vm.services.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize().background(DarkBg),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Bienvenido,", color = MutedText, fontSize = 12.sp)
                    Text(vm.user.name, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onLogout) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, "Cerrar sesión", tint = MutedText)
                }
            }
            Spacer(Modifier.height(12.dp))
            AppTextField(query, { vm.query.value = it }, "Buscar corte o servicio...", icon = Icons.Default.Search)
            Spacer(Modifier.height(12.dp))
            Text("Nuestros Servicios", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        if (services.isEmpty()) item { EmptyState("No se encontraron servicios.") }

        items(services, key = { it.id }) { s -> ServiceCard(s) { onReserve(s.id) } }

        item { SustainableOptionsCard() }
    }
}

@Composable
private fun ServiceCard(s: ServiceItem, onReserve: () -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(s.description, color = MutedText, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text("⏱ ${s.durationMin} min", color = MutedText, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(money(s.price), color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Button(
                    onClick = onReserve,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
                ) { Text("Reservar", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Anexo 2 (impacto social): sección "Opciones sostenibles". Contenido estático por ahora. */
@Composable
private fun SustainableOptionsCard() {
    AppCard {
        Text("🌱 Opciones sostenibles", color = Success, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        listOf(
            "Reservas 100% digitales: sin agendas ni papel.",
            "Productos con envases reciclables.",
            "Uso responsable del agua y menos descartables.",
            "Cancela con anticipación para que otro cliente use tu horario."
        ).forEach { Text("• $it", color = MutedText, fontSize = 12.sp) }
    }
}
