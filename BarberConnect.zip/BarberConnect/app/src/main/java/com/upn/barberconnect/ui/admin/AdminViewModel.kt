package com.upn.barberconnect.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.upn.barberconnect.data.BarberRepository
import com.upn.barberconnect.data.local.AppointmentDetail
import com.upn.barberconnect.data.local.ServiceItem
import com.upn.barberconnect.data.local.Status
import com.upn.barberconnect.util.shortDay
import com.upn.barberconnect.util.stateInVm
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

enum class AgendaMode(val label: String) { DIA("Día"), SEMANA("Semana"), MES("Mes") }

data class DayBar(val label: String, val total: Double)

class AdminViewModel(private val repo: BarberRepository) : ViewModel() {

    private val today = LocalDate.now()

    // ----- HU09: dashboard -----
    val incomeToday = repo.incomeForDate(today.toString()).stateInVm(this, 0.0)
    val activeCount = repo.activeCount().stateInVm(this, 0)

    /** Últimos 7 días (rellena con 0 los días sin ingresos). */
    val weekly: StateFlow<List<DayBar>> = repo
        .incomeBetween(today.minusDays(6).toString(), today.toString())
        .map { rows ->
            val byDate = rows.associate { it.date to it.total }
            (6 downTo 0).map { i ->
                val d = today.minusDays(i.toLong())
                DayBar(d.shortDay(), byDate[d.toString()] ?: 0.0)
            }
        }.stateInVm(this, emptyList())

    // ----- HU06: agenda -----
    val agendaDate = MutableStateFlow(today)
    val agendaMode = MutableStateFlow(AgendaMode.DIA)
    private val allAppointments = repo.allAppointments().stateInVm(this, emptyList<AppointmentDetail>())

    val agenda: StateFlow<List<AppointmentDetail>> =
        combine(allAppointments, agendaDate, agendaMode) { list, d, mode ->
            list.filter {
                val ad = LocalDate.parse(it.date)
                when (mode) {
                    AgendaMode.DIA -> ad == d
                    AgendaMode.SEMANA ->
                        !ad.isBefore(d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))) &&
                            !ad.isAfter(d.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)))
                    AgendaMode.MES -> YearMonth.from(ad) == YearMonth.from(d)
                }
            }
        }.stateInVm(this, emptyList())

    fun setMode(m: AgendaMode) { agendaMode.value = m }
    fun shiftAgenda(direction: Int) {
        agendaDate.update {
            when (agendaMode.value) {
                AgendaMode.DIA -> it.plusDays(direction.toLong())
                AgendaMode.SEMANA -> it.plusWeeks(direction.toLong())
                AgendaMode.MES -> it.plusMonths(direction.toLong())
            }
        }
    }

    fun advanceStatus(a: AppointmentDetail) {
        val next = Status.next(a.status) ?: return
        viewModelScope.launch { repo.updateStatus(a.id, next) }
    }

    fun cancel(a: AppointmentDetail) = viewModelScope.launch { repo.updateStatus(a.id, Status.CANCELADA) }

    // ----- HU07: servicios y precios -----
    val services = repo.allServices().stateInVm(this, emptyList<ServiceItem>())
    fun saveService(s: ServiceItem) = viewModelScope.launch { repo.saveService(s) }
    fun toggleService(s: ServiceItem) = saveService(s.copy(active = !s.active))

    // ----- HU08: clientes e historial -----
    val clientQuery = MutableStateFlow("")
    val clients = combine(repo.clientSummaries(), clientQuery) { list, q ->
        if (q.isBlank()) list else list.filter { it.name.contains(q, true) || it.phone.contains(q) || it.email.contains(q, true) }
    }.stateInVm(this, emptyList())
}
