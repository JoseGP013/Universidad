package com.upn.barberconnect.util

import java.security.MessageDigest

/**
 * RNF03: las contraseñas nunca se guardan en texto plano.
 * Para producción se recomienda migrar a Firebase Authentication o bcrypt/argon2 con sal por usuario.
 */
object Security {
    private const val PEPPER = "barberconnect::"

    fun hash(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest((PEPPER + password).toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
