package com.upn.barberconnect.ui.client

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.ui.components.AppCard
import com.upn.barberconnect.ui.components.GoldButton
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.*
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun BookingScreen(vm: ClientViewModel, onBack: () -> Unit, onDone: () -> Unit) {
    val b by vm.booking.collectAsStateWithLifecycle()
    val barbers by vm.barbers.collectAsStateWithLifecycle()
    val taken by vm.takenTimes.collectAsStateWithLifecycle()
    val days = remember { (0..13).map { LocalDate.now().plusDays(it.toLong()) } }
    val service = b.service

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹", color = Gold, fontSize = 28.sp) }
            Text("Reservar Cita en Línea", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Gold)
        }

        if (service == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
            return@Column
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(service.name, fontWeight = FontWeight.Bold)
                        Text("Duración: ${service.durationMin} min", color = MutedText, fontSize = 12.sp)
                    }
                    Text(money(service.price), color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }

            SectionLabel("1. Elige tu Barbero")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                barbers.forEach { barber ->
                    val selected = b.barberId == barber.id
                    Column(
                        Modifier.clip(RoundedCornerShape(12.dp)).clickable { vm.selectBarber(barber.id) }
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(60.dp).clip(CircleShape)
                                .background(if (selected) Gold else Color(0xFF333333)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(initials(barber.name), fontWeight = FontWeight.Bold,
                                color = if (selected) Color.Black else Color.White)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(barber.name, fontSize = 12.sp, color = if (selected) Gold else MutedText)
                    }
                }
            }

            SectionLabel("2. Fecha")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(days) { d ->
                    val selected = d == b.date
                    Column(
                        Modifier.clip(RoundedCornerShape(10.dp))
                            .background(if (selected) Gold else CardBg)
                            .clickable { vm.selectDate(d) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(d.shortDay(), fontSize = 11.sp, color = if (selected) Color.Black else MutedText)
                        Text("${d.dayOfMonth}", fontWeight = FontWeight.Bold, color = if (selected) Color.Black else LightText)
                    }
                }
            }

            SectionLabel("3. Horario Disponible (Tiempo Real)")
            TIME_SLOTS.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { t ->
                        val isPast = b.date == LocalDate.now() && !LocalTime.parse(t).isAfter(LocalTime.now())
                        SlotChip(t, taken = t in taken || isPast, selected = b.time == t, modifier = Modifier.weight(1f)) { vm.selectTime(t) }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            b.error?.let { Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)) }
            Spacer(Modifier.height(12.dp))
        }

        Box(Modifier.fillMaxWidth().background(CardBg).padding(16.dp)) {
            GoldButton("Confirmar y Asegurar Cita", { vm.confirmBooking() }, loading = b.loading)
        }
    }

    // Confirmación + mensaje de consumo responsable (Anexo 2)
    b.confirmedCode?.let { code ->
        AlertDialog(
            onDismissRequest = { vm.clearBookingResult(); onDone() },
            containerColor = CardBg,
            title = { Text("¡Cita reservada con éxito!", color = Gold) },
            text = {
                Text(
                    "Tu código es #$code.\n\n🌱 Si no podrás asistir, cancela con anticipación: " +
                        "así otro cliente aprovecha ese horario y cuidamos mejor los recursos de la barbería."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.clearBookingResult(); onDone() }) { Text("Ver mis citas", color = Gold) }
            }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 20.dp, bottom = 10.dp))
}

@Composable
private fun SlotChip(time: String, taken: Boolean, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(8.dp))
            .background(if (selected) Gold else CardBg)
            .clickable(enabled = !taken, onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            time, fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = when { selected -> Color.Black; taken -> MutedText.copy(alpha = 0.4f); else -> LightText },
            textDecoration = if (taken) TextDecoration.LineThrough else TextDecoration.None
        )
    }
}
