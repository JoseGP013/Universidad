package com.upn.barberconnect.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.data.local.Status
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*
import com.upn.barberconnect.util.monthYear
import com.upn.barberconnect.util.pretty
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen(vm: AdminViewModel) {
    val agenda by vm.agenda.collectAsStateWithLifecycle()
    val date by vm.agendaDate.collectAsStateWithLifecycle()
    val mode by vm.agendaMode.collectAsStateWithLifecycle()

    val title = when (mode) {
        AgendaMode.DIA -> date.pretty()
        AgendaMode.SEMANA -> {
            val mon = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            "${mon.dayOfMonth}/${mon.monthValue} – ${mon.plusDays(6).let { "${it.dayOfMonth}/${it.monthValue}" }}"
        }
        AgendaMode.MES -> date.monthYear()
    }

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        ScreenTitle("Gestión de Agenda")
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.shiftAgenda(-1) }) { Text("‹", color = Gold, fontSize = 26.sp) }
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            TextButton(onClick = { vm.shiftAgenda(1) }) { Text("›", color = Gold, fontSize = 26.sp) }
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AgendaMode.values().forEach { m ->
                FilterChip(
                    selected = mode == m, onClick = { vm.setMode(m) }, label = { Text(m.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Gold, selectedLabelColor = Color.Black
                    )
                )
            }
        }
        LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (agenda.isEmpty()) item { EmptyState("Sin citas en este periodo.") }
            items(agenda, key = { it.id }) { a ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(a.time, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                StatusChip(a.status)
                            }
                            if (mode != AgendaMode.DIA) Text(a.date, color = MutedText, fontSize = 11.sp)
                            Text(a.clientName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("${a.serviceName} • Barbero: ${a.barberName}", color = MutedText, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Status.next(a.status)?.let { next ->
                                OutlinedButton(onClick = { vm.advanceStatus(a) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) {
                                    Text("→ ${Status.label(next)}", fontSize = 11.sp, color = Gold)
                                }
                            }
                            if (a.status == Status.CONFIRMADA) {
                                TextButton(onClick = { vm.cancel(a) }) { Text("Cancelar", color = Danger, fontSize = 11.sp) }
                            }
                        }
                    }
                }
            }
        }
    }
}
