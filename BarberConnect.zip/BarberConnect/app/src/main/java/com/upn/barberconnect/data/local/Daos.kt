package com.upn.barberconnect.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(user: User): Long

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun findByEmail(email: String): User?

    @Query(
        """SELECT u.id AS id, u.name AS name, u.phone AS phone, u.email AS email,
                  COUNT(a.id) AS visits, COALESCE(SUM(s.price), 0) AS total
           FROM users u
           LEFT JOIN appointments a ON a.clientId = u.id AND a.status = 'COMPLETADA'
           LEFT JOIN services s ON s.id = a.serviceId
           WHERE u.role = 'CLIENT'
           GROUP BY u.id
           ORDER BY u.name"""
    )
    fun observeClientSummaries(): Flow<List<ClientSummary>>
}

@Dao
interface ServiceDao {
    @Query("SELECT * FROM services WHERE active = 1 ORDER BY id")
    fun observeActive(): Flow<List<ServiceItem>>

    @Query("SELECT * FROM services ORDER BY id")
    fun observeAll(): Flow<List<ServiceItem>>

    @Query("SELECT * FROM services WHERE id = :id")
    suspend fun getById(id: Long): ServiceItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(service: ServiceItem): Long
}

@Dao
interface BarberDao {
    @Query("SELECT * FROM barbers ORDER BY id")
    fun observeAll(): Flow<List<Barber>>
}

@Dao
interface AppointmentDao {
    @Insert
    suspend fun insert(appointment: Appointment): Long

    @Query("SELECT COUNT(*) FROM appointments WHERE barberId = :barberId AND date = :date AND time = :time AND status != 'CANCELADA'")
    suspend fun countConflicts(barberId: Long, date: String, time: String): Int

    @Query("SELECT time FROM appointments WHERE barberId = :barberId AND date = :date AND status != 'CANCELADA'")
    fun observeTakenTimes(barberId: Long, date: String): Flow<List<String>>

    @Query("UPDATE appointments SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Query("SELECT * FROM appointments WHERE id = :id")
    suspend fun getById(id: Long): Appointment?

    @Query(
        """SELECT a.id AS id, a.code AS code, a.clientId AS clientId, u.name AS clientName,
                  s.name AS serviceName, s.price AS price, b.name AS barberName,
                  a.date AS date, a.time AS time, a.status AS status
           FROM appointments a
           JOIN users u ON u.id = a.clientId
           JOIN services s ON s.id = a.serviceId
           JOIN barbers b ON b.id = a.barberId
           WHERE a.clientId = :clientId
           ORDER BY a.date DESC, a.time DESC"""
    )
    fun observeByClient(clientId: Long): Flow<List<AppointmentDetail>>

    @Query(
        """SELECT a.id AS id, a.code AS code, a.clientId AS clientId, u.name AS clientName,
                  s.name AS serviceName, s.price AS price, b.name AS barberName,
                  a.date AS date, a.time AS time, a.status AS status
           FROM appointments a
           JOIN users u ON u.id = a.clientId
           JOIN services s ON s.id = a.serviceId
           JOIN barbers b ON b.id = a.barberId
           ORDER BY a.date ASC, a.time ASC"""
    )
    fun observeAll(): Flow<List<AppointmentDetail>>

    @Query("SELECT COUNT(*) FROM appointments WHERE status IN ('CONFIRMADA','EN_PROCESO')")
    fun observeActiveCount(): Flow<Int>

    @Query(
        """SELECT COALESCE(SUM(s.price), 0) FROM appointments a
           JOIN services s ON s.id = a.serviceId
           WHERE a.date = :date AND a.status != 'CANCELADA'"""
    )
    fun observeIncomeForDate(date: String): Flow<Double>

    @Query(
        """SELECT a.date AS date, SUM(s.price) AS total FROM appointments a
           JOIN services s ON s.id = a.serviceId
           WHERE a.status != 'CANCELADA' AND a.date BETWEEN :from AND :to
           GROUP BY a.date"""
    )
    fun observeIncomeBetween(from: String, to: String): Flow<List<DayIncome>>
}

@Dao
interface NotificationDao {
    @Insert
    suspend fun insert(n: AppNotification): Long

    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeByUser(userId: Long): Flow<List<AppNotification>>

    @Query("SELECT COUNT(*) FROM notifications WHERE userId = :userId AND isRead = 0")
    fun observeUnreadCount(userId: Long): Flow<Int>

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllRead(userId: Long)
}
