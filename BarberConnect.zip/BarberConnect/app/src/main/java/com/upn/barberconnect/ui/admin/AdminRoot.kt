package com.upn.barberconnect.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.upn.barberconnect.AppViewModelFactory
import com.upn.barberconnect.rememberContainer
import com.upn.barberconnect.ui.components.BottomBar
import com.upn.barberconnect.ui.components.NavItem
import com.upn.barberconnect.ui.theme.DarkBg

private const val A_DASH = "dashboard"
private const val A_AGENDA = "agenda"
private const val A_SERVICES = "services"
private const val A_CLIENTS = "clients"

@Composable
fun AdminRoot(onLogout: () -> Unit) {
    val vm: AdminViewModel = viewModel(factory = AppViewModelFactory(rememberContainer()))
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route

    val items = listOf(
        NavItem(A_DASH, "Dashboard", Icons.Default.Home),
        NavItem(A_AGENDA, "Agenda", Icons.Default.DateRange),
        NavItem(A_SERVICES, "Servicios", Icons.Default.List),
        NavItem(A_CLIENTS, "Clientes", Icons.Default.Person)
    )

    Scaffold(
        containerColor = DarkBg,
        bottomBar = {
            BottomBar(items, route) { target ->
                nav.navigate(target) {
                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = A_DASH, modifier = Modifier.padding(pad).background(DarkBg)) {
            composable(A_DASH) { DashboardScreen(vm, onLogout) }
            composable(A_AGENDA) { AgendaScreen(vm) }
            composable(A_SERVICES) { AdminServicesScreen(vm) }
            composable(A_CLIENTS) { AdminClientsScreen(vm) }
        }
    }
}
