package com.upn.barberconnect.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object Role {
    const val CLIENT = "CLIENT"
    const val ADMIN = "ADMIN"
}

object Status {
    const val CONFIRMADA = "CONFIRMADA"
    const val EN_PROCESO = "EN_PROCESO"
    const val COMPLETADA = "COMPLETADA"
    const val CANCELADA = "CANCELADA"

    fun label(s: String) = when (s) {
        CONFIRMADA -> "Confirmada"
        EN_PROCESO -> "En proceso"
        COMPLETADA -> "Completada"
        CANCELADA -> "Cancelada"
        else -> s
    }

    /** Flujo de estados que usa el administrador en la agenda (HU06). */
    fun next(s: String): String? = when (s) {
        CONFIRMADA -> EN_PROCESO
        EN_PROCESO -> COMPLETADA
        else -> null
    }
}

@Entity(tableName = "users", indices = [Index(value = ["email"], unique = true)])
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    val passwordHash: String,
    val role: String
)

@Entity(tableName = "services")
data class ServiceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String,
    val durationMin: Int,
    val price: Double,
    val active: Boolean = true
)

@Entity(tableName = "barbers")
data class Barber(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(
    tableName = "appointments",
    indices = [Index(value = ["barberId", "date", "time"]), Index(value = ["clientId"])]
)
data class Appointment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val clientId: Long,
    val serviceId: Long,
    val barberId: Long,
    val date: String,   // yyyy-MM-dd
    val time: String,   // HH:mm
    val status: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications", indices = [Index(value = ["userId"])])
data class AppNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val title: String,
    val message: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

// ---------- Proyecciones (resultados de JOIN) ----------
data class AppointmentDetail(
    val id: Long,
    val code: String,
    val clientId: Long,
    val clientName: String,
    val serviceName: String,
    val price: Double,
    val barberName: String,
    val date: String,
    val time: String,
    val status: String
)

data class DayIncome(val date: String, val total: Double)

data class ClientSummary(
    val id: Long,
    val name: String,
    val phone: String,
    val email: String,
    val visits: Int,
    val total: Double
)
