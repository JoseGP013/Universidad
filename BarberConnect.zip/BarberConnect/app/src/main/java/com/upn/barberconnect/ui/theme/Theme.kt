package com.upn.barberconnect.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paleta tomada del prototipo HTML (gold / darkBg / cardBg)
val Gold = Color(0xFFD4AF37)
val GoldDark = Color(0xFFB5952F)
val DarkBg = Color(0xFF121212)
val CardBg = Color(0xFF1E1E1E)
val LightText = Color(0xFFF3F4F6)
val MutedText = Color(0xFF9CA3AF)
val BorderGray = Color(0xFF2E2E2E)
val Success = Color(0xFF4ADE80)
val Info = Color(0xFF60A5FA)
val Danger = Color(0xFFEF5350)

private val Scheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color.Black,
    secondary = GoldDark,
    background = DarkBg,
    onBackground = LightText,
    surface = CardBg,
    onSurface = LightText,
    surfaceVariant = CardBg,
    onSurfaceVariant = MutedText,
    outline = BorderGray,
    error = Danger
)

@Composable
fun BarberConnectTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
