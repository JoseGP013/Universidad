package com.upn.barberconnect.ui.client

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationsScreen(vm: ClientViewModel) {
    val list by vm.notifications.collectAsStateWithLifecycle()
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }

    // Al salir de la pantalla las alertas se marcan como leídas (quita el badge)
    DisposableEffect(Unit) { onDispose { vm.markNotificationsRead() } }

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        ScreenTitle("Notificaciones y Alertas", "Recordatorios automáticos de tus servicios")
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (list.isEmpty()) item { EmptyState("No tienes notificaciones.") }
            items(list, key = { it.id }) { n ->
                AppCard {
                    Row {
                        Text(
                            (if (!n.isRead) "● " else "") + n.title,
                            fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            color = if (!n.isRead) Gold else LightText, modifier = Modifier.weight(1f)
                        )
                        Text(fmt.format(Date(n.createdAt)), color = MutedText, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(n.message, color = MutedText, fontSize = 12.sp)
                }
            }
        }
    }
}
