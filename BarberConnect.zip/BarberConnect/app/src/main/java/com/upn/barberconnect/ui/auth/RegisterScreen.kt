package com.upn.barberconnect.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.upn.barberconnect.AppViewModelFactory
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.rememberContainer
import com.upn.barberconnect.ui.components.*
import com.upn.barberconnect.ui.theme.*

@Composable
fun RegisterScreen(onRegistered: (SessionUser) -> Unit, onBack: () -> Unit) {
    val vm: AuthViewModel = viewModel(factory = AppViewModelFactory(rememberContainer()))
    val state by vm.state.collectAsStateWithLifecycle()

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    LaunchedEffect(state.user) {
        state.user?.let { onRegistered(it); vm.consumeUser() }
    }

    Column(
        Modifier.fillMaxSize().background(DarkBg).verticalScroll(rememberScrollState())
            .systemBarsPadding().padding(horizontal = 28.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("‹ Volver", color = Gold, modifier = Modifier.clickable { onBack() })
        Text("Crear cuenta", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Regístrate como cliente para reservar tus citas.", color = MutedText, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))

        AppTextField(name, { name = it }, "Nombre completo", icon = Icons.Default.Person)
        AppTextField(email, { email = it }, "Correo electrónico", icon = Icons.Default.Email, keyboardType = KeyboardType.Email)
        AppTextField(phone, { phone = it }, "Teléfono", icon = Icons.Default.Phone, keyboardType = KeyboardType.Phone)
        AppTextField(pass, { pass = it }, "Contraseña (mín. 6 caracteres)", icon = Icons.Default.Lock, isPassword = true)
        AppTextField(confirm, { confirm = it }, "Confirmar contraseña", icon = Icons.Default.Lock, isPassword = true)

        state.error?.let { Text(it, color = Danger, fontSize = 12.sp) }

        Text(
            "Tus datos se guardan de forma local y la contraseña se almacena cifrada (hash).",
            color = MutedText, fontSize = 11.sp
        )
        GoldButton("Registrarme", { vm.register(name, email, phone, pass, confirm) }, loading = state.loading)
    }
}
