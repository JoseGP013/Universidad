package com.upn.barberconnect.data

import android.content.Context

data class SessionUser(val id: Long, val name: String, val role: String)

/** Sesión persistente simple (SharedPreferences). */
class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)

    fun save(user: SessionUser) {
        prefs.edit().putLong("id", user.id).putString("name", user.name).putString("role", user.role).apply()
    }

    fun get(): SessionUser? {
        val id = prefs.getLong("id", -1)
        val role = prefs.getString("role", null)
        val name = prefs.getString("name", null)
        return if (id > 0 && role != null && name != null) SessionUser(id, name, role) else null
    }

    fun clear() = prefs.edit().clear().apply()
}
