package com.upn.barberconnect.util

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/** Horarios base de atención (los mismos del prototipo). */
val TIME_SLOTS = listOf("09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "14:00", "14:30", "15:00", "16:00")

private val ES: Locale = Locale.forLanguageTag("es-PE")

fun LocalDate.shortDay(): String =
    dayOfWeek.getDisplayName(TextStyle.SHORT, ES).replaceFirstChar { it.uppercase() }

fun LocalDate.pretty(): String = format(DateTimeFormatter.ofPattern("EEE d MMM yyyy", ES))

fun LocalDate.monthYear(): String = format(DateTimeFormatter.ofPattern("MMMM yyyy", ES))
    .replaceFirstChar { it.uppercase() }

fun money(v: Double): String = "S/ " + String.format(Locale.US, "%.2f", v)

fun initials(name: String): String =
    name.split(" ").mapNotNull { it.firstOrNull()?.uppercaseChar() }.take(2).joinToString("")

fun <T> Flow<T>.stateInVm(vm: ViewModel, initial: T): StateFlow<T> =
    stateIn(vm.viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)
