package com.upn.barberconnect.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.upn.barberconnect.util.Security
import java.time.LocalDate

@Database(
    entities = [User::class, ServiceItem::class, Barber::class, Appointment::class, AppNotification::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun serviceDao(): ServiceDao
    abstract fun barberDao(): BarberDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "barber_connect.db")
                .addCallback(SeedCallback)
                .build()
                .also { INSTANCE = it }
        }
    }
}

/** Datos de demostración (los mismos del prototipo HTML) cargados al crear la BD. */
private object SeedCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        val now = System.currentTimeMillis()
        val today = LocalDate.now()

        fun user(name: String, email: String, phone: String, pass: String, role: String) = db.execSQL(
            "INSERT INTO users (name, email, phone, passwordHash, role) VALUES (?,?,?,?,?)",
            arrayOf<Any>(name, email, phone, Security.hash(pass), role)
        )
        user("Administrador", "admin@barber.com", "999 000 111", "admin123", Role.ADMIN)            // id 1
        user("Jhordan Flores Tirado", "cliente@barber.com", "987 654 321", "123456", Role.CLIENT) // id 2
        user("María Quispe", "maria@barber.com", "955 111 222", "123456", Role.CLIENT)           // id 3

        fun service(name: String, desc: String, min: Int, price: Double) = db.execSQL(
            "INSERT INTO services (name, description, durationMin, price, active) VALUES (?,?,?,?,1)",
            arrayOf<Any>(name, desc, min, price)
        )
        service("Corte Clásico", "Tijera y máquina profesional", 30, 25.0)
        service("Corte + Barba VIP", "Toalla caliente y perfilado con navaja", 45, 35.0)
        service("Coloración y Estilo", "Tintes y acabados modernos", 60, 50.0)

        db.execSQL("INSERT INTO barbers (name) VALUES (?)", arrayOf<Any>("Jose A."))
        db.execSQL("INSERT INTO barbers (name) VALUES (?)", arrayOf<Any>("Carlos R."))

        fun appt(code: String, client: Long, svc: Long, barber: Long, date: LocalDate, time: String, status: String) =
            db.execSQL(
                "INSERT INTO appointments (code, clientId, serviceId, barberId, date, time, status, createdAt) VALUES (?,?,?,?,?,?,?,?)",
                arrayOf<Any>(code, client, svc, barber, date.toString(), time, status, now)
            )
        appt("BC-101", 2, 1, 1, today, "09:30", Status.CONFIRMADA)
        appt("BC-102", 3, 2, 2, today.plusDays(1), "15:00", Status.CONFIRMADA)
        appt("BC-090", 2, 2, 2, today.minusDays(1), "10:00", Status.COMPLETADA)
        appt("BC-085", 2, 3, 1, today.minusDays(2), "11:00", Status.COMPLETADA)
        appt("BC-080", 2, 1, 1, today.minusDays(4), "14:00", Status.COMPLETADA)
        appt("BC-070", 3, 1, 2, today.minusDays(5), "16:00", Status.COMPLETADA)

        db.execSQL(
            "INSERT INTO notifications (userId, title, message, createdAt, isRead) VALUES (?,?,?,?,0)",
            arrayOf<Any>(2, "Recordatorio de cita", "Tienes una reserva programada hoy a las 09:30.", now)
        )
    }
}
