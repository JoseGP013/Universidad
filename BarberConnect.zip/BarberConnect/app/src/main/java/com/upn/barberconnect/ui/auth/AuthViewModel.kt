package com.upn.barberconnect.ui.auth

import android.util.Patterns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.upn.barberconnect.data.BarberRepository
import com.upn.barberconnect.data.SessionManager
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.data.local.Role
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val user: SessionUser? = null
)

class AuthViewModel(
    private val repo: BarberRepository,
    private val session: SessionManager
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    /** HU01 – criterios: pide correo y contraseña; rechaza datos incorrectos; separa cliente / admin. */
    fun login(email: String, password: String, expectedRole: String) {
        if (email.isBlank() || password.isBlank()) {
            _state.update { it.copy(error = "Ingresa tu correo y contraseña.") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val user = repo.login(email, password)
            when {
                user == null -> _state.update { it.copy(loading = false, error = "Correo o contraseña incorrectos.") }
                user.role != expectedRole -> _state.update {
                    it.copy(
                        loading = false,
                        error = if (expectedRole == Role.ADMIN) "Esta cuenta no tiene permisos de administrador."
                        else "Usa «Ingresar como Admin» para esta cuenta."
                    )
                }
                else -> {
                    val su = SessionUser(user.id, user.name, user.role)
                    session.save(su)
                    _state.update { it.copy(loading = false, user = su) }
                }
            }
        }
    }

    fun register(name: String, email: String, phone: String, password: String, confirm: String) {
        val error = when {
            name.isBlank() || email.isBlank() || phone.isBlank() -> "Completa todos los campos."
            !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "El correo no es válido."
            phone.filter { it.isDigit() }.length < 9 -> "El teléfono debe tener al menos 9 dígitos."
            password.length < 6 -> "La contraseña debe tener al menos 6 caracteres."
            password != confirm -> "Las contraseñas no coinciden."
            else -> null
        }
        if (error != null) {
            _state.update { it.copy(error = error) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            repo.registerClient(name, email, phone, password).fold(
                onSuccess = { u ->
                    val su = SessionUser(u.id, u.name, u.role)
                    session.save(su)
                    _state.update { it.copy(loading = false, user = su) }
                },
                onFailure = { e -> _state.update { it.copy(loading = false, error = e.message) } }
            )
        }
    }

    fun clearError() = _state.update { it.copy(error = null) }
    fun consumeUser() = _state.update { it.copy(user = null) }
}
