package com.upn.barberconnect.ui.client

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.upn.barberconnect.AppViewModelFactory
import com.upn.barberconnect.data.SessionUser
import com.upn.barberconnect.rememberContainer
import com.upn.barberconnect.ui.components.BottomBar
import com.upn.barberconnect.ui.components.NavItem
import com.upn.barberconnect.ui.theme.DarkBg

private const val R_SERVICES = "services"
private const val R_BOOK = "book"
private const val R_APPTS = "appointments"
private const val R_NOTIFS = "notifications"

@Composable
fun ClientRoot(user: SessionUser, onLogout: () -> Unit) {
    val vm: ClientViewModel = viewModel(key = "client_${user.id}", factory = AppViewModelFactory(rememberContainer(), user))
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val unread by vm.unread.collectAsStateWithLifecycle()

    val items = listOf(
        NavItem(R_SERVICES, "Inicio", Icons.Default.Home),
        NavItem(R_APPTS, "Mis Citas", Icons.Default.DateRange),
        NavItem(R_NOTIFS, "Alertas", Icons.Default.Notifications, badge = unread)
    )

    Scaffold(
        containerColor = DarkBg,
        bottomBar = {
            if (route != R_BOOK) BottomBar(items, route) { target ->
                nav.navigate(target) {
                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = R_SERVICES, modifier = Modifier.padding(pad).background(DarkBg)) {
            composable(R_SERVICES) {
                ServicesScreen(vm, onReserve = { id -> vm.startBooking(id); nav.navigate(R_BOOK) }, onLogout = onLogout)
            }
            composable(R_BOOK) {
                BookingScreen(
                    vm,
                    onBack = { nav.popBackStack() },
                    onDone = {
                        nav.navigate(R_APPTS) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = false }
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable(R_APPTS) { MyAppointmentsScreen(vm) }
            composable(R_NOTIFS) { NotificationsScreen(vm) }
        }
    }
}
